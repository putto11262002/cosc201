package cosc201.a1;


/**
 * Skeleton code for Assignment 1 in COSC201. Methods to be filled in according
 * to the specifications in the javadoc and/or the assignment PDF. Please check
 * if it's at all unclear to you what is required.
 * 
 * @author <your name and ID number here>
 */
public class MapAnalyser {

  private Map m;
  
  public MapAnalyser(Map m) {
    this.m = m;
  }

  /**
   * Counts the seas in the map, m.
   * 
   * The 'sea' that a given water cell belongs to consists of all of its water
   * neighbours, all their water neighbours, etc. That is, it is a region of
   * water so that every other cell that has a neighbour belonging to the
   * region must be land.
   *
   * @return the number of different seas in m.
   */
  public int countSeas() {
    // Fill in your code here.
    return -1; // Just so the skeleton code compiles
  }
  
  /**
   * Determines the size of the sea containing the cell in row r and
   * column c in the map, m.
   * 
   * The 'sea' that a given water cell belongs to consists of all of its water
   * neighbours, all their water neighbours, etc. That is, it is a region of
   * water so that every other cell that has a neighbour belonging to the
   * region must be land.
   *
   * @return the size of the sea containing the given cell.
   */
  public int seaSize(int r, int c) {
    // Fill in your code here.
    return -1; // Just so the skeleton code compiles
  }

  
}
